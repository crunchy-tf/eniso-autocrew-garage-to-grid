# Autocrew: Garage to Grid — starter

Prepare this prototype for a wet track.

Edit lighting.cfg, steering.cfg, dashboard.cfg, sensors.cfg and tyres.cfg.
Record focused changes on feature branches. Inspect, discuss and merge them.

This archive contains plain files: no Git repository or credentials.
Initialize real Git with `git init -b main`, then add and commit the baseline.
The illustrative workshop-demo URL belongs only to the website simulation.
For the real lab, create your own GitHub repository and use its actual URL.
